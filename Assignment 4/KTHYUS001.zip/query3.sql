select phone from customers
where salesRepEmployeeNumber is null