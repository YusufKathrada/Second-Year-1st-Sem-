delete from orders
where orderNumber = 10101